var img1;
var img2;
var img3;
var words="Rats can be kept as pets!";

function preload() {
img1=loadImage("rat1.jpg");  
img2=loadImage("rat2.jpg");
img3=loadImage("rat3.jpg");
} 

function setup() {
createCanvas(850, 750);
colorMode(RGB, 255, 255, 255, 1)
textFont("Times New Roman");
}

function draw() {
background(220);
image(img1,0,0,mouseX*2,mouseY*2);
image(img2,500,0,200,200);
image(img3,0,700,400,50);
stroke(10,10,10);
fill(70,70,220);
textSize(35);
text(words,220,500,400,100);
}