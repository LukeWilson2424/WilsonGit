let osc;
let playing;
let freq;
let amp;
var cam;

function setup() {
let cnv = createCanvas(300, 300);
cnv.mousePressed(playOscillator);
osc = new p5.Oscillator('sine');
  
cam = createCapture();
cam.hide();
}

function draw() {
background(100) //making the square and text
fill(230);
textSize(30);
text('Click to play sound', 20, 160);
  
freq= constrain(map(mouseX, 0, width, 100, 500), 100, 500);
amp= constrain(map(mouseY, height, 0, 0, 1), 0, 1);

  if (playing) {
    osc.freq(freq, 0.1);
    osc.amp(amp, 0.1);
    
    strokeWeight(3); //click and move the mouse left-right to make the lines move
    line(freq,120,amp,120);
    line(freq,180,amp,180);
    
image(cam, 0, 0, width, 100);
filter(INVERT);
  }
}

function playOscillator() {
osc.start();
playing = true;
}

function mouseReleased() {
osc.amp(0, 1);
playing = false;
}