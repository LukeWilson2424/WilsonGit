let movie;
function setup(){
noCanvas();
movie = createVideo(
['assets/astro.mp4', 'assets/astro.ogv', 'assets/astro.webm'],
    movieLoad
);
movie.size(380, 300);
}

function movieLoad() {
  movie.loop();
  movie.speed(10.5);
  movie.autoplay();
  movie.hideControls();
  movie.volume(5);
  movie.duration();
  movie.play();

}